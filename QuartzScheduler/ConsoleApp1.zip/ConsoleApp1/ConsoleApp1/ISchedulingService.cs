﻿// See https://aka.ms/new-console-template for more information
namespace ConsoleApp1
{
    public interface ISchedulingService
    {
        void Run();
    }
}